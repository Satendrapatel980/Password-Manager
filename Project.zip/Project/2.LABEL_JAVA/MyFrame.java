// import java.awt.Color;
// import javax.swing.JFrame;

// public class MyFrame extends JFrame {
//     MyFrame(){
        
//         this.setTitle("This is my first frame");
//         this.setLocationRelativeTo(null);
//         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         this.setResizable(false);
//         this.setSize(900,900);
//         this.setVisible(true);
//         // frame.getContentPane().setBackground(Color.CYAN);
//         // frame.getContentPane().setBackground(new Color(190,100,250));
//         this.getContentPane().setBackground(new Color(0x123456));
//     }
// }
