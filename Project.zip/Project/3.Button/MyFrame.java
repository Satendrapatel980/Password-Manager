import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MyFrame extends JFrame implements ActionListener{


    JButton button;
    MyFrame(){
        button = new JButton("Add Password");
        button.setBounds(200,100,200,50);
        button.setFocusable(false);
        button.setVerticalAlignment(JButton.CENTER);
        button.setHorizontalAlignment(JButton.CENTER);
        button.setFont(new Font("Comic Sans", Font.BOLD, 23));
        button.setIconTextGap(10);
        button.setBorder(BorderFactory.createEtchedBorder());
        button.addActionListener(e -> System.out.println("Enter password"));
        button.setBackground(Color.GRAY);



        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setSize(500,500);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.BLUE);;
        this.add(button);


    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button){
            // System.out.println("Enter your Password");
            // button.setEnabled(false);
        }
    }
    
}
